package jp.groupsession.v2.newplugin.helloworld;

  import java.sql.Connection;



import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.groupsession.v2.cmn.dao.GroupModel;
import jp.groupsession.v2.struts.AbstractGsAction;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

  import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.*;
import java.text.*;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.ss.util.CellReference;



import java.util.stream.Collectors;
import java.util.stream.IntStream;




  public class HelloWorldAction extends AbstractGsAction {




//*****************クラス内で使う関数******************test
	  public static String ZtoH(String s) {
		    StringBuffer sb = new StringBuffer(s);
		    for (int i = 0; i < sb.length(); i++) {
		      char c = sb.charAt(i);
		      if (c >= '０' && c <= '９') {
		        sb.setCharAt(i, (char)(c - '０' + '0'));
		      }
		    }
		    return sb.toString();
		  }

	  public static String HtoZ(String str) {
	        if (str == null){
	            throw new IllegalArgumentException();
	        }
	        StringBuffer sb = new StringBuffer(str);
	        for (int i = 0; i < str.length(); i++) {
	            char c = str.charAt(i);
	            if ('0' <= c && c <= '9') {
	                sb.setCharAt(i, (char) (c - '0' + '０'));
	            }
	        }
	        return sb.toString();
	    }

	  private static String Cval(int dValue) {
			 Calendar cal = Calendar.getInstance();
        	 cal.set(1900, 0, 1, 12, 0, 0);

        	 //1900/1/1のシリアルが1なので、加算する値は取得した値 - 1になる
        	 int serial = dValue - 1;
        	 //1900/2/29は存在しないがエクセル内では存在しているらしいので
        	 //その日付以降であればさらに -1
        	 serial -= (serial > 60 ? 1 : 0);
        	 //基準日に加算
        	 cal.add(Calendar.DATE, serial);
        	 //確認のために表示
        	 String cellValue=String.format("%1$tm/%1$td",cal);
        	 return cellValue;
	  }

//*****************************************************************************************************************************
	  private static String teikeishori(Workbook wb,String month) {
		   String tmp="";
		    String tuki,hi[];
		    Integer konnendo;

		    Calendar ffday  = new GregorianCalendar();
		    int fyear=ffday.get(Calendar.YEAR);
		    konnendo=fyear;
		    int fmonth=ffday.get(Calendar.MONTH)+1;//今月
		    if (fmonth<=3) konnendo=konnendo-1;

 		   String gatu="";

 		   Integer sm=Integer.parseInt(month)-4;

					if(Integer.parseInt(month)>0 && Integer.parseInt(month)<=3){
						sm=Integer.parseInt(month)+8;

					}

					if (Integer.parseInt(month)==4 && fmonth==3){//３月に次の４月シートを表示させるため
						sm=12;

					}


			        Sheet sheet = wb.getSheetAt(sm);
			        gatu=wb.getSheetName(sm);//シート名は　○月の形式だとする
		         	tuki="00"+ZtoH(gatu).replace("月","");
	            	 tuki = tuki.substring(tuki.length()-2,tuki.length());


            		  if(month.equals(tuki)){

            			  //out.print("<div><table id=hyo width=95% border=1 style='font-size:12px;border-collapse:collapse;'>");
                           tmp=tmp+"<div><table id=hyo width=95% border=1 style='font-size:12px;border-collapse:collapse;'>";

            			  for (Row row : sheet) {//各行移動
					       //out.print("<tr>");
					      tmp=tmp+"<tr>";
            				  int cct=0;
					            for (Cell cell : row) {//各セル移動
					                String cellValue = null;
					                int cellType = cell.getCellType();

					                switch (cellType) {
					                case Cell.CELL_TYPE_NUMERIC:
					                    double dValue = cell.getNumericCellValue();
					                    cellValue = String.valueOf(dValue);
					                    break;
					                case Cell.CELL_TYPE_STRING:
					                    cellValue = cell.getStringCellValue();
					                    break;
					                default:
					                	 cellValue="";
					                    break;
					                }
					                // セル値の出力
					                cellValue=cellValue.replace(".0","").replace(",","、");

					                	String width="";
					                	switch (cct){
					                	case 0:
					                		width="width=25";
					                		break;
					                	case 1:
					                		width="width=15";
					                		break;

					                	default:
					                		width="";
					                		break;
					                	}

					                	//out.print("<td "+width+" align=left>"+cellValue+"</td>");
					                   tmp=tmp+"<td "+width+" align=left>"+cellValue+"</td>";


					                cct=cct+1;
					            }
					            //out.print("</tr>");
					            tmp=tmp+"</tr>";

	            	       }
            		   //out.print("</table><div>");
            		   tmp=tmp+"</table><div>";
            		  }

          	 List<String> TkStLst= List.of("04","05","06","07","08","09","10","11","12","01","02","03");
   			 String mon=month;
   			 String opts=TkStLst.stream().map(x -> mon.equals(x) ? "<option value=\""+x+"\" selected >"+x+"月</option>" :	"<option value=\""+x+"\" >"+x+"月</option>" )
   			 .collect(Collectors.joining(" "));
   			 tmp= "<form method=\"post\" action=\"#\">\r\n" +
   			 	  		"<select property=\"opt\" name=\"opt\" onchange=\"submit(this.form)\">"+
   			 				opts+
   			 			"</select>"
   			 		+ "</form>"+tmp;


		  return tmp;
	  }

	  private static String tsuruyoshori(Workbook wb,String month) {
		 //System.out.print("1:");
		  String tmp="";
		  try {




			   int sheetsu=wb.getNumberOfSheets();

			     List<String>  TkStLst=IntStream.range(0, wb.getNumberOfSheets())
	             .mapToObj(wb::getSheetAt)
	             .map(Sheet::getSheetName)
	             .collect(Collectors.toList());

			     String mon=month;
			     int index = IntStream.range(0, TkStLst.size()).filter(i->TkStLst.get(i).equals(mon)).findAny().orElse(0);

			     Sheet sheet = wb.getSheetAt(index);

				// System.out.print("2:");

			     List<CellRangeAddress> rangeLst=new ArrayList<CellRangeAddress>();
				 //System.out.print("3a:");



	             for(int i=0;i<sheet.getNumMergedRegions();i++) {
	            //	 System.out.print(""+i);
	            	 rangeLst.add(sheet.getMergedRegion(i));
	             }

		        // List<CellRangeAddress> rangeLst = IntStream.range(0, sheet.getNumMergedRegions()).map( i ->  sheet.getMergedRegion(i)  ).collect(Collectors.toList());

			     //IntStream.range(0, sheet.getNumMergedRegions()).forEach(i->System.out.println(sheet.getMergedRegion(i).getFirstRow()));

	     			  //out.print("<div><table id=hyo width=95% border=1 style='font-size:12px;border-collapse:collapse;'>");

	        	 //System.out.print("3b:");
	                    tmp=tmp+"<div><table id=hyo width=95% border=1 style='font-size:12px;border-collapse:collapse;'>";
	                 int yi=0;
	                 int kugyo=0;
	                 boolean flg=true;
	     			  for (Row row : sheet) {//各行移動
					       //out.print("<tr>");
                          flg=true;
					      tmp=tmp+"<tr>";
	     				  int cct=0;

					            for (Cell cell : row) {//各セル移動
					                String cellValue = null;
					                int cellType = cell.getCellType();

					                switch (cellType) {
					                case Cell.CELL_TYPE_NUMERIC:
					                    int dValue = (int)cell.getNumericCellValue();

					                    if(DateUtil.isCellDateFormatted(cell)) {

					                         cellValue=Cval(dValue); //serail>mm/dd


					                      } else {
					                    	  if (dValue>31&&cct==0) {
					                    		  cellValue=Cval(dValue); //serail>mm/dd
					                    	  }else {
					                    		  cellValue = String.valueOf(dValue);
					                    	  }

					                      }

					                    break;
					                case Cell.CELL_TYPE_STRING:
					                    cellValue = cell.getStringCellValue();
					                    break;
					                default:
					                	 cellValue="";
					                    break;
					                }
					                // セル値の出力
					                cellValue=cellValue.replace(".0","").replace(",","、");

					                	String width="";
					                	switch (cct){
					                	case 0:
					                		width="width=25";
					                		break;
					                	case 1:
					                		width="width=15";
					                		break;

					                	default:
					                		width="";
					                		break;

					                	}
					                	//out.print("<td "+width+" align=left>"+cellValue+"</td>");

					                	String cksr=cellketugoshori(cct,yi,width,rangeLst,cellValue);
					                	if (cksr.replaceAll("<.+?>", "").isEmpty()) {
					                		flg=flg&&true;
					                	}else {
					                		flg=flg&&false;
					                	}
	                                  tmp=tmp+ cksr;
					                  // tmp=tmp+"<td "+width+" align=left>"+cellValue+"</td>";


					                cct=cct+1;
					            }
					            //out.print("</tr>");


					            tmp=tmp+"</tr>";
	                     yi++;

				            if(flg==true) {
				            	kugyo++;
				            }else {
				            	kugyo=0;
				            }
				            if(kugyo>4) {
				            	break;
				            }



	         	       }
	     		   //out.print("</table><div>");
	     		   tmp=tmp+"</table><div>";


	     			// System.out.print("3L:");

	   			 String opts=TkStLst.stream().map(x -> mon.equals(x) ? "<option value=\""+x+"\" selected >"+x+"</option>" :	"<option value=\""+x+"\" >"+x+"</option>" )
	   			 .collect(Collectors.joining(" "));
	   			 tmp= "<form method=\"post\" action=\"#\">\r\n" +
	   			 	  		"<select property=\"opt\" name=\"opt\" onchange=\"submit(this.form)\">"+
	   			 				opts+
	   			 			"</select>"
	   			 		+ "</form>"+tmp;



		  }catch(Exception e) {
			  tmp=tmp+e.getMessage();
				// System.out.print("error:");
		  }


	   return tmp;
	  }


	  private static String cellketugoshori(int cct,int yi,String width, List<CellRangeAddress> rangeLst,String cellValue) {

		  // final int size = sheet.getNumMergedRegions();
	        //    for (int i = 0; i < size; i++) {
	        //        final CellRangeAddress range = sheet.getMergedRegion(i);
	        //        final int firstRow = range.getFirstRow();
	        //        final int firstColumn = range.getFirstColumn();
	        //        final int lastRow = range.getLastRow();
	        //        final int lastColumn = range.getLastColumn();
	               // System.out.println("結合セル" + (i + 1) + "個目");
	               // System.out.println("開始：" + CellReference.convertNumToColString(firstColumn) + (firstRow + 1));
	               // System.out.println("終了：" + CellReference.convertNumToColString(lastColumn) + (lastRow + 1));
	                // セルの左上の値を取得
	                // 左上のセル以外にもし値が入っていても表示上見えないはずなので無視する
	            //    final Row row = sheet.getRow(firstRow);
	              //  if (row != null) {
	             //      System.out.println("値：" + getCellValue(row.getCell(firstColumn)));
	              //  }
	               // System.out.println("--------------------------------------------");
	          //  }
			String cst="";

		  try {
				String LTdt=  rangeLst.stream().filter(x->x.getFirstRow()==yi&&x.getFirstColumn()==cct).map(x->cct+","+yi+","+x.getLastColumn()+","+x.getLastRow()).findAny().orElse("");
		        String LTdt2= rangeLst.stream().filter(
		        		x->x.getFirstRow()<yi && x.getLastRow()>=yi && x.getFirstColumn()<cct && x.getLastColumn()>=cct
		        		   || x.getFirstRow()==yi && x.getFirstColumn()<cct && x.getLastColumn()>=cct
		        		   || x.getFirstRow()<yi && x.getLastRow()>=yi && x.getFirstColumn()==cct
		        		).map(x->"DEL").findAny().orElse("");


		        if(LTdt.isEmpty()&&LTdt2.isEmpty() ) { //左上でない　かつ　結合範囲にない

		        	cst="<td "+width+" align=left>"+cellValue+"</td>";


		        }else if(!LTdt.isEmpty()&&LTdt2.isEmpty()){//左上である　かつ　結合範囲にない
		        	String CrSt[]=LTdt.split(",");
		        	String tdst="";
		        	if(!CrSt[0].equals(CrSt[2])) {
		        		tdst=" colspan=\""+  ( Integer.parseInt(CrSt[2])-Integer.parseInt(CrSt[0]) +1 )+"\"";
		        	}
		        	if(!CrSt[1].equals(CrSt[3])) {
		        		tdst=tdst+" rowspan=\""+  ( Integer.parseInt(CrSt[3])-Integer.parseInt(CrSt[1]) +1 )+"\"";
		        	}
		        	cst="<td "+width+" align=left "+tdst+">"+cellValue+"</td>";
		        }

		        else if(LTdt.isEmpty()&&!LTdt2.isEmpty()){//左上でない　かつ　結合範囲である

		        	cst="";

		        }else {		  //左上である　かつ　結合範囲である
		        	cst=""; //ここはありえない

		        }

		  }catch(Exception e) {
			  System.out.print(e.getMessage());
		  }




		  return cst;
	  }


	  //*********************************************************************************************************************
      public ActionForward executeAction(ActionMapping map,
                                          ActionForm form,
                                          HttpServletRequest req,
                                          HttpServletResponse res,
                                          Connection con)
          throws Exception {

     	 HelloWorldForm helloworldForm = (HelloWorldForm)form;



     	  GregorianCalendar cal = new GregorianCalendar();
          SimpleDateFormat format2 = new SimpleDateFormat("MM");
          String datestr_s = format2.format(cal.getTime());
          String hget=helloworldForm.getOpt();
//System.out.print("1:"+datestr_s);
//System.out.print("2:"+ helloworldForm.getOpt());

          String month="00";
          if(hget==null||hget.length()==0)
          {
        	  month=datestr_s;
          }else{
        	  month=hget;
          }



     	 String tmp= helloworldForm.getText();
 //******************************************hyoji bu shori****************


 		    String freset="false";


		    String[] w = {"日","月","火","水","木","金","土"};




		    String tmp3=null;
try {
	String str3 = null;
	BufferedReader in3=new BufferedReader(new FileReader(this.getServlet().getServletContext().getRealPath("/WEB-INF/plugin/newplugin/excel_path.txt")));
	while((str3=in3.readLine())!=null) {
		tmp3=str3;
		//System.out.println("/"+tmp3+"/"+"/");
	}
	in3.close();
}catch(Exception e) {
	tmp=tmp+"excel_path.txtを確認してください";
}



try	{

		//tmp3: xlsx file path;

//******************************************************

		File fl =new File(tmp3);
		if (fl.exists()){


			 InputStream inp = new FileInputStream(tmp3);

			    //（2）入力ファイルを表すワークブックオブジェクトの生成
			    Workbook wb	 = WorkbookFactory.create(inp);

		        String gatu=wb.getSheetName(0);//シート名は　先頭が４月なら　定型処理
	         	String tuki=gatu.replace("月","");

                //System.out.print(tuki);

            	 if(tuki.equals("4")||tuki.equals("４")) {
            		 tmp=tmp+teikeishori(wb,month);
            	 }else {
            		 tmp=tmp+tsuruyoshori(wb,month);
            		 //System.out.print("tsuruyo");
            		// tmp="tsuruyo:"+tmp;
            	 }



			       inp.close();


		}else{
			 //System.out.println(path3+":見つかりません！");
			 //out.print("<tt>*****</tt>\t<tt>予定表示のためには["+tmp3+"]のファイルが必要です</tt>");
		 tmp=tmp+"<tt>*****</tt>\t<tt>予定表示のためには["+tmp3+"]のファイルが必要です</tt>";
		}


	} catch (Exception e) {
         tmp=tmp+"<tt>読み取りエラー。エクセル形式が違います。"+e.getMessage()+"</tt>";
		//　１３以外のシートのときこちらで処理





	}



//*********************************************hyojibu shori owari***************



       helloworldForm.setText(tmp);
       helloworldForm.setOpt(month);


        return map.getInputForward();

}


  }